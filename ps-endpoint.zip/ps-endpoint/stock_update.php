<?php
/**
 * Custom stock update endpoint for PrestaShop 8
 *
 * Supports:
 * - Simple products
 * - One specific combination
 *
 * Example:
 *
 * Simple product:
 * http://localhost/prestashop/stock_update.php
 * ?key=API_KEY
 * &id_product=1
 * &quantity=10
 *
 * Product combination:
 * http://localhost/prestashop/stock_update.php
 * ?key=API_KEY
 * &id_product=1
 * &id_product_attribute=3
 * &quantity=10
 */

require_once __DIR__ . '/config/config.inc.php';

header('Content-Type: application/json; charset=utf-8');

try {

    // =========================================================
    // AUTH
    // =========================================================

    $key = '';

    if (!empty($_SERVER['HTTP_X_API_KEY'])) {
        $key = trim($_SERVER['HTTP_X_API_KEY']);
    } elseif (!empty($_POST['key'])) {
        $key = trim($_POST['key']);
    } elseif (!empty($_GET['key'])) {
        $key = trim($_GET['key']);
    }

    if (empty($key)) {
        http_response_code(401);

        echo json_encode([
            'success' => false,
            'error' => 'Missing API key'
        ]);

        exit;
    }

    $webservice = Db::getInstance()->getRow(
        'SELECT id_webservice_account
         FROM `' . _DB_PREFIX_ . 'webservice_account`
         WHERE `key` = "' . pSQL($key) . '"
         AND `active` = 1'
    );

    if (!$webservice) {
        http_response_code(401);

        echo json_encode([
            'success' => false,
            'error' => 'Unauthorized'
        ]);

        exit;
    }

    // =========================================================
    // PARAMETERS
    // =========================================================

    $idProduct = (int)($_POST['id_product'] ?? $_GET['id_product'] ?? 0);

    $idProductAttribute = (int)($_POST['id_product_attribute'] ?? $_GET['id_product_attribute'] ?? 0);

    $quantity = (int)($_POST['quantity'] ?? $_GET['quantity'] ?? 0);

    if ($idProduct <= 0) {

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'id_product is required'
        ]);

        exit;
    }

    // =========================================================
    // CHECK PRODUCT
    // =========================================================

    if (!Product::existsInDatabase($idProduct, 'product')) {

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Product not found',
            'id_product' => $idProduct
        ]);

        exit;
    }

    // =========================================================
    // SIMPLE PRODUCT
    // =========================================================

    if ($idProductAttribute <= 0) {

        $beforeQty = StockAvailable::getQuantityAvailableByProduct(
            $idProduct,
            0
        );

        $updated = Db::getInstance()->update(
            'stock_available',
            [
                'quantity' => (int)$quantity
            ],
            '
            id_product = ' . (int)$idProduct . '
            AND id_product_attribute = 0
            '
        );

        StockAvailable::synchronize($idProduct);

        $afterQty = StockAvailable::getQuantityAvailableByProduct(
            $idProduct,
            0
        );

        echo json_encode([
            'success' => (bool)$updated,
            'type' => 'simple_product',
            'id_product' => $idProduct,
            'quantity_before' => $beforeQty,
            'quantity_after' => $afterQty,
            'requested_quantity' => $quantity
        ]);

        exit;
    }

    // =========================================================
    // CHECK COMBINATION
    // =========================================================

    $existsCombination = Db::getInstance()->getValue(
        '
        SELECT id_product_attribute
        FROM `' . _DB_PREFIX_ . 'product_attribute`
        WHERE id_product = ' . (int)$idProduct . '
        AND id_product_attribute = ' . (int)$idProductAttribute
    );

    if (!$existsCombination) {

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Combination not found',
            'id_product' => $idProduct,
            'id_product_attribute' => $idProductAttribute
        ]);

        exit;
    }

    // =========================================================
    // UPDATE ONE COMBINATION
    // =========================================================

    $beforeQty = StockAvailable::getQuantityAvailableByProduct(
        $idProduct,
        $idProductAttribute
    );

    $updated = Db::getInstance()->update(
        'stock_available',
        [
            'quantity' => (int)$quantity
        ],
        '
        id_product = ' . (int)$idProduct . '
        AND id_product_attribute = ' . (int)$idProductAttribute
    );

    // RECALCUL TOTAL PRODUCT STOCK
    StockAvailable::synchronize($idProduct);

    $afterQty = StockAvailable::getQuantityAvailableByProduct(
        $idProduct,
        $idProductAttribute
    );

    $totalQty = StockAvailable::getQuantityAvailableByProduct($idProduct);

    echo json_encode([
        'success' => (bool)$updated,
        'type' => 'single_combination',
        'id_product' => $idProduct,
        'id_product_attribute' => $idProductAttribute,
        'quantity_before' => $beforeQty,
        'quantity_after' => $afterQty,
        'total_product_quantity' => $totalQty,
        'requested_quantity' => $quantity
    ]);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
}