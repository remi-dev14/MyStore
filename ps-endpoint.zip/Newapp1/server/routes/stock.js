import { Router } from 'express';
import axios from 'axios';
import { parseStringPromise } from 'xml2js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
dotenv.config();

const router = Router();
const __dirname = dirname(fileURLToPath(import.meta.url));
const HISTORY_FILE = join(__dirname, '../stock_history.json');
const PRESTA_URL = process.env.PRESTASHOP_API_URL;
const auth = { username: process.env.PRESTASHOP_API_KEY, password: '' };

function loadHistory() {
  if (!existsSync(HISTORY_FILE)) return [];
  try { return JSON.parse(readFileSync(HISTORY_FILE, 'utf-8')); } catch { return []; }
}

function saveHistory(data) {
  writeFileSync(HISTORY_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

async function getStockAvailable(productId) {
  const res = await axios.get(`${PRESTA_URL}/stock_availables`, {
    auth,
    params: { display: 'full', 'filter[id_product]': productId, output_format: 'XML' },
    responseType: 'text',
  });
  const parsed = await parseStringPromise(res.data, { explicitArray: false, mergeAttrs: true });
  const stocks = parsed?.prestashop?.stock_availables?.stock_available;
  const list = stocks ? (Array.isArray(stocks) ? stocks : [stocks]) : [];
  return list.find((s) => String(s.id_product_attribute) === '0') ?? list[0];
}

async function getAllStockAvailables(productId) {
  const res = await axios.get(`${PRESTA_URL}/stock_availables`, {
    auth,
    params: { display: 'full', 'filter[id_product]': productId, output_format: 'XML' },
    responseType: 'text',
  });
  const parsed = await parseStringPromise(res.data, { explicitArray: false, mergeAttrs: true });
  const stocks = parsed?.prestashop?.stock_availables?.stock_available;
  return stocks ? (Array.isArray(stocks) ? stocks : [stocks]) : [];
}

router.post('/add', async (req, res) => {
  try {
    const { productId, delta, productAttributeId, applyToAll } = req.body;
    if (!productId || delta === undefined) return res.status(400).json({ error: 'productId and delta required' });

    const intDelta = parseInt(delta, 10);
    if (applyToAll) {
      const list = await getAllStockAvailables(productId);
      if (!list.length) return res.status(404).json({ error: 'No stock entries found for this product' });

      const history = loadHistory();
      const updatedEntries = [];

      for (const sa of list) {
        const oldQty = parseInt(sa.quantity ?? 0, 10);
        const newQty = oldQty + intDelta;
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">\n<stock_available>\n  <id>${sa.id}</id>\n  <id_product>${productId}</id_product>\n  <id_product_attribute>${sa.id_product_attribute ?? 0}</id_product_attribute>\n  <quantity>${newQty}</quantity>\n</stock_available>\n</prestashop>`;

        await axios.put(`${PRESTA_URL}/stock_availables/${sa.id}`, xml, {
          auth,
          headers: { 'Content-Type': 'application/xml' },
        });

        history.push({
          date: new Date().toISOString().split('T')[0],
          productId: String(productId),
          id_product_attribute: String(sa.id_product_attribute ?? 0),
          delta: intDelta,
          oldQty,
          newQty,
        });

        updatedEntries.push({ id: sa.id, oldQty, newQty });
      }

      saveHistory(history);
      return res.json({ success: true, updated: updatedEntries });
    }

    let sa = null;
    if (productAttributeId) {
      const list = await getAllStockAvailables(productId);
      sa = list.find((s) => String(s.id_product_attribute) === String(productAttributeId));
    } else {
      sa = await getStockAvailable(productId);
    }

    if (!sa) return res.status(404).json({ error: 'Stock available not found' });

    const oldQty = parseInt(sa.quantity ?? 0, 10);
    const newQty = oldQty + intDelta;

    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">\n<stock_available>\n  <id>${sa.id}</id>\n  <id_product>${productId}</id_product>\n  <id_product_attribute>${sa.id_product_attribute ?? 0}</id_product_attribute>\n  <quantity>${newQty}</quantity>\n</stock_available>\n</prestashop>`;

    await axios.put(`${PRESTA_URL}/stock_availables/${sa.id}`, xml, {
      auth,
      headers: { 'Content-Type': 'application/xml' },
    });

    const history = loadHistory();
    history.push({
      date: new Date().toISOString().split('T')[0],
      productId: String(productId),
      id_product_attribute: String(sa.id_product_attribute ?? 0),
      delta: intDelta,
      oldQty,
      newQty,
    });
    saveHistory(history);

    res.json({ success: true, oldQty, newQty, id: sa.id });
  } catch (err) {
    res.status(500).json({ error: err.message, detail: err.response?.data ?? null });
  }
});

router.get('/history/:productId', (req, res) => {
  const history = loadHistory();
  const filtered = history.filter((h) => String(h.productId) === String(req.params.productId));
  res.json(filtered);
});

export default router;
