import { Router } from 'express';
import multer from 'multer';
import axios from 'axios';
import AdmZip from 'adm-zip';
import dotenv from 'dotenv';
import { parseStringPromise } from 'xml2js';
import { parseCsvText, parseDecimal, parsePercent, detectFileType, parseAchat } from '../../src/utils/csvParser.js';
import { frDateToIso } from '../../src/utils/dateUtils.js';
import { buildProductXml, buildCustomerXml, buildAddressXml, buildCartXml, buildCategoryXml, buildOrderXml } from '../../src/utils/xmlBuilder.js';

dotenv.config();

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });
const PRESTA_URL = process.env.PRESTASHOP_API_URL;
const PRESTA_KEY = process.env.PRESTASHOP_API_KEY;
const PRESTA_BASE_URL = PRESTA_URL.replace(/\/api\/?$/, '');
const auth = { username: PRESTA_KEY, password: '' };

// --- Utility helpers ---

function ts() {
  return new Date().toISOString().replace('T', ' ').substring(0, 23);
}

// Extract readable PS error from a raw response string
function prestaErrorDetail(err) {
  const data = err.response?.data;
  if (!data) return '';
  const str = typeof data === 'string' ? data : JSON.stringify(data);
  const m = str.match(/<message[^>]*>([\s\S]*?)<\/message>/i)
    || str.match(/<error[^>]*>([\s\S]*?)<\/error>/i);
  if (m) return m[1].replace(/<[^>]+>/g, '').trim().substring(0, 300);
  return str.substring(0, 300);
}

// Guard: throw early with readable message if response is not XML.
// Catches HTML error pages, PHP Fatal errors, "Forbidden" plain text, etc.
function assertXml(raw, context) {
  const trimmed = (raw || '').trim();
  if (!trimmed.startsWith('<')) {
    throw new Error(`Réponse non-XML [${context}]: "${trimmed.substring(0, 400)}"`);
  }
}

async function prestaGet(path, params = {}) {
  const res = await axios.get(`${PRESTA_URL}/${path}`, { auth, params, responseType: 'text' });
  return parseStringPromise(res.data, { explicitArray: false, mergeAttrs: true });
}

async function prestaPost(path, xml) {
  let res;
  try {
    res = await axios.post(`${PRESTA_URL}/${path}`, xml, {
      auth, headers: { 'Content-Type': 'application/xml' }, responseType: 'text',
    });
  } catch (e) {
    const raw = typeof e.response?.data === 'string' ? e.response.data : '';
    const status = e.response?.status || 0;
    throw new Error(`HTTP ${status} POST /${path} — ${raw.substring(0, 500) || e.message}`, { cause: e });
  }
  const raw = res.data || '';
  assertXml(raw, `POST /${path} HTTP ${res.status}`);
  return parseStringPromise(raw, { explicitArray: false, mergeAttrs: true });
}


function normalizeRow(row) {
  return Object.fromEntries(Object.entries(row).map(([k, v]) => [String(k).trim().toLowerCase(), v]));
}

function getId(parsed, resource) {
  return parsed?.prestashop?.[resource]?.id ?? null;
}

function getLang(field, id = '1') {
  if (!field) return '';
  if (typeof field === 'string') return field;
  const langs = Array.isArray(field.language) ? field.language : [field.language].filter(Boolean);
  const m = langs.find((l) => String(l.id) === String(id));
  return m?._ ?? m ?? '';
}

function splitName(nom) {
  const parts = (nom || '').trim().split(/\s+/);
  if (parts.length >= 2) {
    return { firstname: parts.slice(0, -1).join(' '), lastname: parts[parts.length - 1] };
  }
  return { firstname: nom || 'Client', lastname: nom || 'Client' };
}

function safePasswd(raw) {
  const p = (raw || '').trim();
  return p.length >= 8 ? p : (p + 'Aa12345!').substring(0, Math.max(8, p.length));
}

// Strip accents + lowercase for etat comparison
function normalizeEtat(str) {
  return (str || '').trim().toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '');
}

const PS_STATE_PAID = 2;       // Payment accepted
const PS_STATE_CANCELLED = 6;  // Cancelled

// --- Deduplication helpers ---

async function findProductByReference(reference) {
  try {
    const res = await prestaGet('products', {
      display: 'full',
      'filter[reference]': `[${reference}]`,
      output_format: 'XML',
    });
    const products = res?.prestashop?.products?.product;
    if (!products) return null;
    const list = Array.isArray(products) ? products : [products];
    return list[0]?.id ?? null;
  } catch {
    return null;
  }
}

async function findCustomerByEmail(email) {
  try {
    const res = await prestaGet('customers', {
      display: 'full',
      'filter[email]': `[${email}]`,
      output_format: 'XML',
    });
    const customers = res?.prestashop?.customers?.customer;
    if (!customers) return null;
    const list = Array.isArray(customers) ? customers : [customers];
    return list[0]?.id ?? null;
  } catch {
    return null;
  }
}

async function findAddressForCustomer(customerId) {
  try {
    const res = await prestaGet('addresses', {
      display: 'full',
      'filter[id_customer]': customerId,
      output_format: 'XML',
    });
    const addresses = res?.prestashop?.addresses?.address;
    if (!addresses) return null;
    const list = Array.isArray(addresses) ? addresses : [addresses];
    return list[0]?.id ?? null;
  } catch {
    return null;
  }
}

async function ensureCategory(name, log, report) {
  const catXml = await prestaGet('categories', { display: 'full', output_format: 'XML' });
  const cats = catXml?.prestashop?.categories?.category;
  const list = cats ? (Array.isArray(cats) ? cats : [cats]) : [];
  const found = list.find((c) => getLang(c.name, '1')?.toLowerCase() === name.toLowerCase());
  if (found) {
    log.push(`[${ts()}] Catégorie existante utilisée : "${name}" (id=${found.id})`);
    report.categories.existing++;
    return found.id;
  }
  const xml = buildCategoryXml({ name });
  const created = await prestaPost('categories', xml);
  const id = getId(created, 'category');
  log.push(`[${ts()}] Catégorie créée : "${name}" (id=${id})`);
  report.categories.created++;
  return id;
}

// Cached default country ID (queried once from PS_COUNTRY_DEFAULT config, fallback = 8 = France)
let _cachedCountryId = null;
async function getDefaultCountryId() {
  if (_cachedCountryId) return _cachedCountryId;
  try {
    const res = await prestaGet('configurations', {
      display: 'full',
      'filter[name]': '[PS_COUNTRY_DEFAULT]',
      output_format: 'XML',
    });
    const confs = res?.prestashop?.configurations?.configuration;
    const list = confs ? (Array.isArray(confs) ? confs : [confs]) : [];
    const conf = list.find((c) => c.name === 'PS_COUNTRY_DEFAULT');
    _cachedCountryId = String(conf?.value ?? '8');
  } catch {
    _cachedCountryId = '8'; // France fallback
  }
  return _cachedCountryId;
}

// Finds or creates a PS tax_rule_group for a given tax rate.
// Strategy: load all taxes + all tax_rules, join by id_tax, find a rule that matches
// the rate AND the default country (or country=0 which PS treats as "all").
// If none found: reuse existing tax record or create one, then create a new
// tax_rule_group + tax_rule bound to the real default country.
async function findOrCreateTaxRuleGroup(taxPercent, cache, log) {
  const rateKey = parseFloat(taxPercent.toFixed(3));
  const cacheKey = String(rateKey);
  if (cache[cacheKey]) return cache[cacheKey];

  try {
    const countryId = await getDefaultCountryId();

    // --- Load all taxes and build taxId → rate map ---
    const taxRes = await prestaGet('taxes', { display: 'full', output_format: 'XML' });
    const taxesRaw = taxRes?.prestashop?.taxes?.tax;
    const taxList = taxesRaw ? (Array.isArray(taxesRaw) ? taxesRaw : [taxesRaw]) : [];
    const taxRateMap = {};
    for (const t of taxList) taxRateMap[String(t.id)] = parseFloat(t.rate);

    // --- Load all tax_rules and find one matching rate + country ---
    const ruleRes = await prestaGet('tax_rules', { display: 'full', output_format: 'XML' });
    const rulesRaw = ruleRes?.prestashop?.tax_rules?.tax_rule;
    const ruleList = rulesRaw ? (Array.isArray(rulesRaw) ? rulesRaw : [rulesRaw]) : [];

    const matchRule = ruleList.find((r) => {
      const rate = taxRateMap[String(r.id_tax)];
      if (rate === undefined) return false;
      if (Math.abs(rate - rateKey) >= 0.01) return false;
      const ruleCountry = String(r.id_country);
      return ruleCountry === '0' || ruleCountry === countryId;
    });

    if (matchRule) {
      const groupId = String(matchRule.id_tax_rules_group);
      cache[cacheKey] = groupId;
      log.push(`[${ts()}] Taxe ${rateKey}% : groupe id=${groupId} (règle existante, pays=${matchRule.id_country})`);
      return groupId;
    }

    // --- No matching rule — reuse or create tax record ---
    const matchTax = taxList.find((t) => Math.abs(parseFloat(t.rate) - rateKey) < 0.01);
    let taxId = matchTax ? String(matchTax.id) : null;

    if (!taxId) {
      const taxName = `TVA ${rateKey}%`;
      const taxXml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<tax>
  <rate>${rateKey.toFixed(3)}</rate>
  <active>1</active>
  <name>
    <language id="1"><![CDATA[${taxName}]]></language>
    <language id="2"><![CDATA[${taxName}]]></language>
  </name>
</tax>
</prestashop>`;
      const taxCreated = await prestaPost('taxes', taxXml);
      taxId = String(getId(taxCreated, 'tax'));
      log.push(`[${ts()}] Taxe ${rateKey}% : enregistrement créé (id=${taxId})`);
    } else {
      log.push(`[${ts()}] Taxe ${rateKey}% : enregistrement existant réutilisé (id=${taxId})`);
    }

    // --- Create tax_rule_group ---
    const groupName = `TVA ${rateKey}%`;
    const groupXml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<tax_rule_group>
  <name><![CDATA[${groupName}]]></name>
  <active>1</active>
</tax_rule_group>
</prestashop>`;
    const groupCreated = await prestaPost('tax_rule_groups', groupXml);
    const newGroupId = String(getId(groupCreated, 'tax_rule_group'));

    // --- Create tax_rule linking group + country + tax ---
    const ruleXml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<tax_rule>
  <id_tax_rules_group>${newGroupId}</id_tax_rules_group>
  <id_country>${countryId}</id_country>
  <id_state>0</id_state>
  <id_tax>${taxId}</id_tax>
  <behavior>0</behavior>
  <description><![CDATA[]]></description>
  <zipcode_from></zipcode_from>
  <zipcode_to></zipcode_to>
</tax_rule>
</prestashop>`;
    await prestaPost('tax_rules', ruleXml);

    cache[cacheKey] = newGroupId;
    log.push(`[${ts()}] Taxe ${rateKey}% : groupe créé (id=${newGroupId}), règle pays=${countryId}, tax id=${taxId})`);
    return newGroupId;
  } catch (e) {
    throw new Error(`Règle taxe ${rateKey}%: ${e.message} — vérifier les permissions webservice (taxes, tax_rule_groups, tax_rules)`, { cause: e });
  }
}

// Calls the custom stock_update.php endpoint deployed in the PS root.
// PS8 blocks POST on stock_availables (HTTP 405), so we use this dedicated
// PHP script that calls StockAvailable::setQuantity() / Db::update() directly.
// idProductAttribute=0 → base product; >0 → specific combination.
async function updateStock(productId, quantity, log, idProductAttribute = 0) {
  const attrLabel = idProductAttribute > 0 ? ` attr=${idProductAttribute}` : '';
  log.push(`[${ts()}] Stock : product id=${productId}${attrLabel}, qty cible=${quantity}`);
  const url = `${PRESTA_BASE_URL}/stock_update.php`;
  const params = { id_product: productId, quantity, key: PRESTA_KEY };
  if (idProductAttribute > 0) params.id_product_attribute = idProductAttribute;
  const body = new URLSearchParams(params).toString();
  let res;
  try {
    res = await axios.post(url, body, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });
  } catch (e) {
    const msg = e.response?.data?.error ?? e.message;
    throw new Error(`Stock endpoint HTTP ${e.response?.status ?? 0}: ${msg}`, { cause: e });
  }
  if (!res.data?.success) {
    throw new Error(`Échec stock product id=${productId}${attrLabel}: ${res.data?.error ?? 'unknown'}`);
  }
  const before = res.data.quantity_before ?? '?';
  const after = res.data.quantity_after ?? quantity;
  log.push(`[${ts()}] Stock : mis à jour product id=${productId}${attrLabel} (avant=${before} → après=${after})`);
  return true;
}

// --- Import route ---

router.post('/', upload.array('files'), async (req, res) => {
  const log = [];
  const errors = [];
  const report = {
    categories: { created: 0, existing: 0 },
    products: { created: 0, existing: 0, failed: 0 },
    clients: { created: 0, existing: 0, failed: 0 },
    paniers: { created: 0, failed: 0 },
    commandes: { created: 0, failed: 0 },
    images: { uploaded: 0, skipped: 0, failed: 0 },
  };

  try {
    const files = req.files || [];
    let f1Rows = [], f2Rows = [], f3Rows = [], zipFile = null;

    for (const file of files) {
      if (file.originalname.endsWith('.zip')) { zipFile = file; continue; }
      const text = file.buffer.toString('utf-8');
      const rows = parseCsvText(text).map(normalizeRow);
      if (!rows.length) continue;
      const type = detectFileType(Object.keys(rows[0]));
      const cols = Object.keys(rows[0]);
      log.push(`[${ts()}] Fichier : ${file.originalname} → ${type} (${rows.length} lignes, ${cols.length} col: ${cols.slice(0, 6).join(', ')}${cols.length > 6 ? '…' : ''})`);
      if (type === 'fichier1') f1Rows = rows;
      else if (type === 'fichier2') f2Rows = rows;
      else if (type === 'fichier3') f3Rows = rows;
    }

    // STEP 1: Products
    const productMap = {};
    const taxGroupCache = {}; // rate → id_tax_rule_group (per-import cache)
    for (const row of f1Rows) {
      const ref = (row.reference || '').trim();
      if (!ref) { errors.push(`[${ts()}] Produit sans référence ignoré : ${row.nom}`); continue; }
      try {
        const existingId = await findProductByReference(ref);
        if (existingId) {
          productMap[ref] = existingId;
          report.products.existing++;
          log.push(`[${ts()}] Produit existant utilisé : ${row.nom} (ref=${ref}, id=${existingId})`);
          continue;
        }

        const taxPercent = parsePercent(row.taxe);
        const priceTTC = parseDecimal(row.prix_ttc);
        if (priceTTC <= 0) throw new Error(`prix_ttc invalide : "${row.prix_ttc}"`);
        const priceHT = taxPercent > 0 ? priceTTC / (1 + taxPercent / 100) : priceTTC;
        const wholesalePrice = parseDecimal(row.prix_achat);
        const categoryId = await ensureCategory(row.categorie || 'Produits', log, report);
        const taxRuleGroupId = await findOrCreateTaxRuleGroup(taxPercent, taxGroupCache, log);
        const availableDate = frDateToIso(row.date_availability_produit);

        const xml = buildProductXml({
          name: row.nom,
          reference: ref,
          price: priceHT.toFixed(6),
          wholesale_price: wholesalePrice.toFixed(6),
          id_tax_rules_group: taxRuleGroupId,
          id_category_default: categoryId,
          available_date: availableDate,
        });
        const created = await prestaPost('products', xml);
        const pid = getId(created, 'product');
        if (!pid) throw new Error('Aucun id produit retourné par PrestaShop');
        productMap[ref] = pid;
        report.products.created++;
        log.push(`[${ts()}] Produit créé : ${row.nom} (ref=${ref}, id=${pid}, TTC=${priceTTC.toFixed(2)}, HT=${priceHT.toFixed(4)}, taxe=${taxPercent}%, groupe taxe id=${taxRuleGroupId})`);
      } catch (e) {
        report.products.failed++;
        const detail = prestaErrorDetail(e);
        errors.push(`[${ts()}] ERREUR Produit "${row.nom}" ref=${ref}: ${e.message}${detail ? ' — PS: ' + detail : ''}`);
      }
    }

    // STEP 2: Stock
    // Group by (reference, variant): rows with a variant key get a separate call
    // so each combination is updated individually via id_product_attribute.
    // Rows without a variant (or with variant='') are aggregated into attribute=0.
    const stockByKey = {};  // "ref::variant" → qty
    const groupByKey = {};  // "ref::variant" → attribute group name (from specificité column)
    for (const row of f2Rows) {
      const ref = (row.reference || '').trim();
      // karazany = variant VALUE (ngoza, kely, mainty…)
      // specificité = group TYPE (taille, couleur…) — column key may be misencoded, find by prefix
      const variant = (row.karazany || '').trim();
      const qty = parseInt(parseDecimal(row.stock_initial), 10) || 0;
      const key = `${ref}::${variant}`;
      stockByKey[key] = (stockByKey[key] ?? 0) + qty;
      if (variant && !groupByKey[key]) {
        const grpEntry = Object.entries(row).find(([k]) => k.startsWith('specif'));
        const grpRaw = (grpEntry?.[1] || '').trim();
        groupByKey[key] = grpRaw
          ? grpRaw.charAt(0).toUpperCase() + grpRaw.slice(1)  // "taille"→"Taille"
          : 'Déclinaison';
      }
    }

    // Session caches: avoid repeated API calls for the same group/value within one import run
    const optionGroupCache = {};  // groupName.lower → id
    const optionValueCache = {};  // `${groupId}::${valueName.lower}` → id
    const comboMap = {};          // "ref::variant" → id_product_attribute (for cart rows)

    for (const [key, qty] of Object.entries(stockByKey)) {
      const [ref, variant] = key.split('::');
      try {
        const pid = productMap[ref];
        if (!pid) {
          errors.push(`[${ts()}] ERREUR Stock : ref="${ref}" inconnue (produit non importé)`);
          continue;
        }

        let attrId = 0;

        if (variant) {
          // 1. Find or create attribute group (type from specificité column)
          const GROUP = groupByKey[key] || 'Déclinaison';
          const gKey = GROUP.toLowerCase();
          if (!optionGroupCache[gKey]) {
            const gRes = await prestaGet('product_options', { display: 'full', output_format: 'XML' });
            const opts = gRes?.prestashop?.product_options?.product_option;
            const optList = opts ? (Array.isArray(opts) ? opts : [opts]) : [];
            const found = optList.find((o) => getLang(o.name, '1').toLowerCase() === gKey);
            if (found) {
              optionGroupCache[gKey] = found.id;
              log.push(`[${ts()}] Groupe attribut existant : "${GROUP}" (id=${found.id})`);
            } else {
              const gXml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<product_option>
  <is_color_group>0</is_color_group>
  <group_type>select</group_type>
  <name>
    <language id="1"><![CDATA[${GROUP}]]></language>
    <language id="2"><![CDATA[${GROUP}]]></language>
  </name>
  <public_name>
    <language id="1"><![CDATA[${GROUP}]]></language>
    <language id="2"><![CDATA[${GROUP}]]></language>
  </public_name>
</product_option>
</prestashop>`;
              const gCreated = await prestaPost('product_options', gXml);
              optionGroupCache[gKey] = getId(gCreated, 'product_option');
              log.push(`[${ts()}] Groupe attribut créé : "${GROUP}" (id=${optionGroupCache[gKey]})`);
            }
          }
          const groupId = optionGroupCache[gKey];

          // 2. Find or create attribute value (the variant name)
          const vKey = `${groupId}::${variant.toLowerCase()}`;
          if (!optionValueCache[vKey]) {
            const vRes = await prestaGet('product_option_values', {
              display: 'full',
              'filter[id_attribute_group]': `[${groupId}]`,
              output_format: 'XML',
            });
            const vals = vRes?.prestashop?.product_option_values?.product_option_value;
            const valList = vals ? (Array.isArray(vals) ? vals : [vals]) : [];
            const foundVal = valList.find((v) => getLang(v.name, '1').toLowerCase() === variant.toLowerCase());
            if (foundVal) {
              optionValueCache[vKey] = foundVal.id;
              log.push(`[${ts()}] Valeur attribut existante : "${variant}" (id=${foundVal.id})`);
            } else {
              const vXml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<product_option_value>
  <id_attribute_group>${groupId}</id_attribute_group>
  <color></color>
  <name>
    <language id="1"><![CDATA[${variant}]]></language>
    <language id="2"><![CDATA[${variant}]]></language>
  </name>
</product_option_value>
</prestashop>`;
              const vCreated = await prestaPost('product_option_values', vXml);
              optionValueCache[vKey] = getId(vCreated, 'product_option_value');
              log.push(`[${ts()}] Valeur attribut créée : "${variant}" (id=${optionValueCache[vKey]})`);
            }
          }
          const optionValueId = optionValueCache[vKey];

          // 3. Find or create combination (product + attribute value)
          const cRes = await prestaGet('combinations', {
            display: 'full',
            'filter[id_product]': `[${pid}]`,
            output_format: 'XML',
          });
          const combos = cRes?.prestashop?.combinations?.combination;
          const comboList = combos ? (Array.isArray(combos) ? combos : [combos]) : [];
          const foundCombo = comboList.find((c) => {
            const ov = c.associations?.product_option_values?.product_option_value;
            const ovList = ov ? (Array.isArray(ov) ? ov : [ov]) : [];
            return ovList.some((v) => String(v.id) === String(optionValueId));
          });

          // Compute price offset for this variant relative to base product
          const f1rowForPrice = f1Rows.find((r) => r.reference === ref);
          const f2rowForPrice = f2Rows.find((r) => r.reference === ref && (r.karazany || '').trim() === variant);
          let priceOffset = 0;
          if (f2rowForPrice?.prix_vente_ttc && f1rowForPrice) {
            const variantTTC = parseDecimal(f2rowForPrice.prix_vente_ttc);
            const taxPct = parsePercent(f1rowForPrice.taxe);
            const baseHT = parseDecimal(f1rowForPrice.prix_ttc) / (taxPct > 0 ? 1 + taxPct / 100 : 1);
            const variantHT = variantTTC / (taxPct > 0 ? 1 + taxPct / 100 : 1);
            priceOffset = variantHT - baseHT;
          }

          if (foundCombo) {
            attrId = parseInt(foundCombo.id, 10) || 0;
            log.push(`[${ts()}] Déclinaison existante : "${variant}" product id=${pid} (attr id=${attrId})`);
          } else {
            const cXml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<combination>
  <id_product>${pid}</id_product>
  <minimal_quantity>1</minimal_quantity>
  <reference><![CDATA[${ref}-${variant}]]></reference>
  <price>${priceOffset.toFixed(6)}</price>
  <weight>0</weight>
  <associations>
    <product_option_values>
      <product_option_value>
        <id>${optionValueId}</id>
      </product_option_value>
    </product_option_values>
  </associations>
</combination>
</prestashop>`;
            const cCreated = await prestaPost('combinations', cXml);
            attrId = parseInt(getId(cCreated, 'combination'), 10) || 0;
            log.push(`[${ts()}] Déclinaison créée : "${variant}" product id=${pid} (attr id=${attrId})`);
          }
          comboMap[key] = attrId;
        }

        await updateStock(pid, qty, log, attrId);
      } catch (e) {
        errors.push(`[${ts()}] ERREUR Stock ref=${ref}${variant ? ' déclinaison=' + variant : ''}: ${e.message}`);
      }
    }

    // STEP 3: Customers
    const customerMap = {};
    const seenEmails = new Set();
    for (const row of f3Rows) {
      const email = (row.email || '').trim();
      if (!email || seenEmails.has(email)) continue;
      seenEmails.add(email);
      try {
        const existingId = await findCustomerByEmail(email);
        if (existingId) {
          const addrId = await findAddressForCustomer(existingId);
          customerMap[email] = { id: existingId, addressId: addrId };
          report.clients.existing++;
          log.push(`[${ts()}] Client existant utilisé : ${email} (id=${existingId}, adresse id=${addrId ?? 'inconnue'})`);
          continue;
        }

        const { firstname, lastname } = splitName(row.nom);
        const passwd = safePasswd(row.pwd);
        const xml = buildCustomerXml({ firstname, lastname, email, passwd });
        const created = await prestaPost('customers', xml);
        const custId = getId(created, 'customer');
        if (!custId) throw new Error('Aucun id client retourné');

        const addrXml = buildAddressXml({
          id_customer: custId,
          alias: 'Domicile',
          address1: row.adresse || '1 rue de Paris',
          city: 'Paris',
          firstname,
          lastname,
        });
        const addrCreated = await prestaPost('addresses', addrXml);
        const addrId = getId(addrCreated, 'address');
        customerMap[email] = { id: custId, addressId: addrId };
        report.clients.created++;
        log.push(`[${ts()}] Client créé : ${firstname} ${lastname} <${email}> (id=${custId}, adresse id=${addrId})`);
      } catch (e) {
        report.clients.failed++;
        const detail = prestaErrorDetail(e);
        errors.push(`[${ts()}] ERREUR Client ${row.email}: ${e.message}${detail ? ' — PS: ' + detail : ''}`);
      }
    }

    // STEP 4: Carts and Orders
    // etat='' or 'dans le panier' → cart only
    // etat='paiement accepté'/'payment effectuer' → cart + order (state=2)
    // etat='annuler' → cart + order (state=6)
    for (const row of f3Rows) {
      const etatNorm = normalizeEtat(row.etat);
      const isPaid = etatNorm === 'paiement accepte' || etatNorm === 'payment effectuer';
      const isCancelled = etatNorm === 'annuler' || etatNorm === 'annule';
      const needsOrder = isPaid || isCancelled;
      const currentState = isCancelled ? PS_STATE_CANCELLED : PS_STATE_PAID;

      try {
        const cust = customerMap[row.email];
        if (!cust) {
          if (row.achat) errors.push(`[${ts()}] ${needsOrder ? 'Commande' : 'Panier'} ignoré : client ${row.email} non disponible`);
          continue;
        }

        const items = parseAchat(row.achat);
        if (!items.length) {
          log.push(`[${ts()}] Pas d'achats pour : ${row.email}`);
          continue;
        }

        const missingRefs = items.filter((item) => !productMap[item.reference]);
        if (missingRefs.length) {
          errors.push(`[${ts()}] ERREUR ${needsOrder ? 'Commande' : 'Panier'} ${row.email}: produits manquants — ${missingRefs.map((i) => i.reference).join(', ')}`);
          if (needsOrder) report.commandes.failed++; else report.paniers.failed++;
          continue;
        }

        // Build cart rows and (if needed) order rows simultaneously
        let totalTTC = 0;
        const cartRows = [];
        const orderRows = [];
        for (const item of items) {
          const itemVariant = (item.variant || '').trim();
          const comboKey = `${item.reference}::${itemVariant}`;
          const f2row = f2Rows.find((r) => r.reference === item.reference && (r.karazany || '').trim() === itemVariant);
          const f1row = f1Rows.find((r) => r.reference === item.reference);
          const unitPriceTTC = f2row?.prix_vente_ttc ? parseDecimal(f2row.prix_vente_ttc) : f1row ? parseDecimal(f1row.prix_ttc) : 0;
          const taxPercent = f1row ? parsePercent(f1row.taxe) : 20;
          const unitPriceHT = taxPercent > 0 ? unitPriceTTC / (1 + taxPercent / 100) : unitPriceTTC;
          totalTTC += unitPriceTTC * item.quantity;
          const attrId = comboMap[comboKey] ?? 0;
          const pid = productMap[item.reference];
          cartRows.push({ product_id: pid, product_attribute_id: attrId, quantity: item.quantity, id_shop: 1 });
          if (needsOrder) {
            orderRows.push({
              product_id: pid,
              product_attribute_id: attrId,
              quantity: item.quantity,
              product_name: f1row?.nom || item.reference,
              product_reference: item.reference,
              product_price: unitPriceHT.toFixed(6),
              unit_price_tax_incl: unitPriceTTC.toFixed(6),
              unit_price_tax_excl: unitPriceHT.toFixed(6),
            });
          }
        }

        // Always create cart first
        const cartXml = buildCartXml({
          id_customer: cust.id,
          id_address_delivery: cust.addressId,
          id_address_invoice: cust.addressId,
          cartRows,
        });
        const cartCreated = await prestaPost('carts', cartXml);
        const cartId = getId(cartCreated, 'cart');
        if (!cartId) throw new Error('Aucun cart id retourné par PrestaShop');

        const orderDate = frDateToIso(row.date) || new Date().toISOString().split('T')[0];
        const etatLabel = (row.etat || '').trim();

        if (!needsOrder) {
          report.paniers.created++;
          log.push(`[${ts()}] Panier créé : ${row.email} (cart id=${cartId}, ${cartRows.length} article(s), total=${totalTTC.toFixed(2)}€${etatLabel ? ', état=' + etatLabel : ''})`);
        } else {
          const totalHT = orderRows.reduce((s, r) => s + parseFloat(r.product_price) * r.quantity, 0);
          const stateLabel = isCancelled ? 'Annulé (import)' : 'Import - Paiement accepté';
          const orderXml = buildOrderXml({
            id_customer: cust.id,
            id_cart: cartId,
            id_address_delivery: cust.addressId,
            id_address_invoice: cust.addressId,
            orderRows,
            current_state: currentState,
            payment: stateLabel,
            module: 'ps_cashondelivery',
            total_paid: totalTTC.toFixed(6),
            total_paid_real: totalTTC.toFixed(6),
            total_paid_tax_incl: totalTTC.toFixed(6),
            total_paid_tax_excl: totalHT.toFixed(6),
            total_products: totalHT.toFixed(6),
            total_products_wt: totalTTC.toFixed(6),
          });
          const orderCreated = await prestaPost('orders', orderXml);
          const orderId = getId(orderCreated, 'order');
          if (!orderId) throw new Error('Aucun order id retourné par PrestaShop');
          report.commandes.created++;
          log.push(`[${ts()}] Commande créée : ${row.email} (order id=${orderId}, cart id=${cartId}, ${orderRows.length} article(s), total=${totalTTC.toFixed(2)}€, date=${orderDate}, état=${etatLabel})`);
        }
      } catch (e) {
        if (needsOrder) report.commandes.failed++; else report.paniers.failed++;
        const detail = prestaErrorDetail(e);
        errors.push(`[${ts()}] ERREUR ${needsOrder ? 'Commande' : 'Panier'} ${row.email}: ${e.message}${detail ? ' — PS: ' + detail : ''}`);
      }
    }

    // STEP 5: Images (ZIP)
    if (zipFile) {
      try {
        const zip = new AdmZip(zipFile.buffer);
        const entries = zip.getEntries().filter(
          (e) => !e.isDirectory && /\.(jpg|jpeg|png|gif|webp)$/i.test(e.entryName) && !e.name.startsWith('._')
        );

        for (const entry of entries) {
          const namePart = entry.name.replace(/\.[^.]+$/, '');
          const pid = productMap[namePart];
          if (!pid) {
            errors.push(`[${ts()}] Image ignorée : "${entry.name}" — référence "${namePart}" inconnue`);
            continue;
          }

          // Check if product already has images
          try {
            const imgCheck = await prestaGet(`images/products/${pid}`, { output_format: 'XML' });
            const imgs = imgCheck?.prestashop?.image?.declination;
            if (imgs && (Array.isArray(imgs) ? imgs.length > 0 : true)) {
              report.images.skipped++;
              log.push(`[${ts()}] Image ignorée (déjà présente) : ${entry.name} → product ${pid}`);
              continue;
            }
          } catch { /* proceed with upload if check fails */ }

          try {
            const ext = entry.name.split('.').pop().toLowerCase();
            const mimeTypes = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp' };
            const contentType = mimeTypes[ext] || 'image/jpeg';
            const FormData = (await import('form-data')).default;
            const form = new FormData();
            form.append('image', entry.getData(), { filename: entry.name, contentType });
            await axios.post(`${PRESTA_URL}/images/products/${pid}`, form, {
              auth,
              headers: form.getHeaders(),
            });
            report.images.uploaded++;
            log.push(`[${ts()}] Image uploadée : ${entry.name} → product ${pid}`);
          } catch (e) {
            report.images.failed++;
            const detail = prestaErrorDetail(e);
            errors.push(`[${ts()}] ERREUR Image ${entry.name}: ${e.message}${detail ? ' — PS: ' + detail : ''}`);
          }
        }
      } catch (e) {
        errors.push(`[${ts()}] ERREUR ZIP: ${e.message}`);
      }
    }

    // Final report
    log.push(`[${ts()}] ===== RAPPORT FINAL =====`);
    log.push(`Catégories : ${report.categories.created} créées, ${report.categories.existing} existantes`);
    log.push(`Produits   : ${report.products.created} créés, ${report.products.existing} existants, ${report.products.failed} échecs`);
    log.push(`Clients    : ${report.clients.created} créés, ${report.clients.existing} existants, ${report.clients.failed} échecs`);
    log.push(`Paniers    : ${report.paniers.created} créés, ${report.paniers.failed} échecs`);
    log.push(`Commandes  : ${report.commandes.created} créées, ${report.commandes.failed} échecs`);
    log.push(`Images     : ${report.images.uploaded} uploadées, ${report.images.skipped} ignorées, ${report.images.failed} échecs`);

    res.json({ success: true, log, errors, report });
  } catch (err) {
    errors.push(`[${ts()}] ERREUR CRITIQUE: ${err.message}`);
    res.status(500).json({ success: false, error: err.message, log, errors });
  }
});

// Reset: delete all products, customers, carts, orders
router.delete('/reset', async (_req, res) => {
  const log = [];
  const errors = [];

  // IDs to never delete regardless of resource (PS system records)
  const PROTECTED_IDS = new Set(['1', '2']);

  async function listIds(resource) {
    try {
      const data = await prestaGet(resource, { output_format: 'XML' });
      const singular = resource.endsWith('ies')
        ? resource.slice(0, -3) + 'y'
        : resource.replace(/s$/, '');
      const items = data?.prestashop?.[resource]?.[singular];
      const list = items ? (Array.isArray(items) ? items : [items]) : [];
      return list.map((item) => String(item?.id ?? item)).filter((id) => id && id !== 'undefined');
    } catch {
      return [];
    }
  }

  async function deleteAll(resource, protectedIds = PROTECTED_IDS) {
    const ids = await listIds(resource);
    let deleted = 0;
    for (const id of ids) {
      if (protectedIds.has(id)) continue;
      try {
        await axios.delete(`${PRESTA_URL}/${resource}/${id}`, { auth });
        deleted++;
      } catch (e) {
        errors.push(`Delete ${resource}/${id}: ${prestaErrorDetail(e) || e.message}`);
      }
    }
    if (deleted > 0) log.push(`[${ts()}] ${resource} : ${deleted} supprimé(s)`);
  }

  const NONE = new Set(); // no protection

  // Delete in dependency order (children before parents)
  // Orders, carts, products, stock: delete everything including id 1 and 2
  await deleteAll('orders', NONE);
  await deleteAll('order_cart_rules', NONE);
  await deleteAll('carts', NONE);
  await deleteAll('cart_rules', NONE);
  await deleteAll('addresses', NONE);
  await deleteAll('customers', NONE);

  // Product combinations before products (all deleted, stock_availables auto-cascade)
  await deleteAll('combinations', NONE);
  await deleteAll('product_features', NONE);
  await deleteAll('product_feature_values', NONE);
  await deleteAll('product_options', NONE);
  await deleteAll('product_option_values', NONE);
  await deleteAll('products', NONE);

  // Categories: keep root (1) and Home (2)
  await deleteAll('categories', PROTECTED_IDS);

  // Tax rules before groups; keep PS default group (id=1)
  await deleteAll('tax_rules', new Set(['1']));
  await deleteAll('tax_rule_groups', new Set(['1']));
  await deleteAll('taxes', new Set(['1']));

  // Misc
  await deleteAll('manufacturers', PROTECTED_IDS);
  await deleteAll('suppliers', PROTECTED_IDS);

  res.json({ success: true, log, errors });
});

export default router;
