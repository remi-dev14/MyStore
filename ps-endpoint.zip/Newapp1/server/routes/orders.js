import { Router } from 'express';
import axios from 'axios';
import { parseStringPromise } from 'xml2js';
import dotenv from 'dotenv';
dotenv.config();

const router = Router();
const PRESTA_URL = process.env.PRESTASHOP_API_URL;
const auth = { username: process.env.PRESTASHOP_API_KEY, password: '' };

router.put('/:id/state', async (req, res) => {
  try {
    const { id } = req.params;
    const { current_state } = req.body;

    const getRes = await axios.get(`${PRESTA_URL}/orders/${id}`, { auth, responseType: 'text' });
    const parsed = await parseStringPromise(getRes.data, { explicitArray: false, mergeAttrs: true });
    const order = parsed?.prestashop?.order;
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<prestashop xmlns:xlink="http://www.w3.org/1999/xlink">
<order>
  <id>${id}</id>
  <id_address_delivery>${order.id_address_delivery}</id_address_delivery>
  <id_address_invoice>${order.id_address_invoice}</id_address_invoice>
  <id_cart>${order.id_cart}</id_cart>
  <id_currency>${order.id_currency}</id_currency>
  <id_lang>${order.id_lang}</id_lang>
  <id_customer>${order.id_customer}</id_customer>
  <id_carrier>${order.id_carrier}</id_carrier>
  <current_state>${current_state}</current_state>
  <module><![CDATA[${order.module ?? 'cod'}]]></module>
  <payment><![CDATA[${order.payment ?? 'Cash on delivery'}]]></payment>
  <conversion_rate>${order.conversion_rate ?? 1}</conversion_rate>
  <total_paid>${order.total_paid}</total_paid>
  <total_paid_real>${order.total_paid_real}</total_paid_real>
  <total_products>${order.total_products}</total_products>
  <total_products_wt>${order.total_products_wt}</total_products_wt>
  <total_shipping>${order.total_shipping}</total_shipping>
  <total_shipping_tax_excl>${order.total_shipping_tax_excl ?? 0}</total_shipping_tax_excl>
  <total_shipping_tax_incl>${order.total_shipping_tax_incl ?? 0}</total_shipping_tax_incl>
  <total_wrapping>${order.total_wrapping ?? 0}</total_wrapping>
  <total_wrapping_tax_excl>${order.total_wrapping_tax_excl ?? 0}</total_wrapping_tax_excl>
  <total_wrapping_tax_incl>${order.total_wrapping_tax_incl ?? 0}</total_wrapping_tax_incl>
</order>
</prestashop>`;

    await axios.put(`${PRESTA_URL}/orders/${id}`, xml, {
      auth,
      headers: { 'Content-Type': 'application/xml' },
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
