import { useState, useRef } from 'react';
import { api } from '../../../config/api.js';
import { parseCsvText, detectFileType } from '../../../utils/csvParser.js';
import { validateCsv } from '../../../utils/importValidation.js';
import { Card, CardTitle } from '../../../shared/ui/Card.jsx';
import { Button } from '../../../shared/ui/Button.jsx';
import { Badge } from '../../../shared/ui/Badge.jsx';
import { Upload, FileText, AlertCircle, CheckCircle, X } from 'lucide-react';

const TYPE_LABELS = {
  fichier1: 'Produits',
  fichier2: 'Stock/Déclinaisons',
  fichier3: 'Clients/Commandes',
  zip: 'Images ZIP',
  unknown: 'Type non reconnu',
};

export default function ImportPage() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState(null);
  const [preview, setPreview] = useState([]);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef(null);

  async function handleFiles(selected) {
    const fileList = Array.from(selected);
    setFiles(fileList);
    setResult(null);
    const previews = [];
    for (const file of fileList) {
      if (file.name.endsWith('.zip')) {
        previews.push({ file: file.name, type: 'zip', columns: [], rows: [], errors: [], total: 0 });
        continue;
      }
      try {
        const text = await file.text();
        const rows = parseCsvText(text);
        const columns = rows.length ? Object.keys(rows[0]) : [];
        const type = detectFileType(columns);
        const errors = validateCsv(rows, type);
        previews.push({ file: file.name, type, columns, rows: rows.slice(0, 5), errors, total: rows.length });
      } catch (e) {
        previews.push({ file: file.name, type: 'error', columns: [], rows: [], errors: [{ row: 0, column: '-', message: e.message }], total: 0 });
      }
    }
    setPreview(previews);
  }

  const hasErrors = preview.some((p) => p.errors.length > 0);

  async function handleImport() {
    if (!files.length || hasErrors) return;
    setLoading(true);
    setProgress(10);
    setResult(null);
    const formData = new FormData();
    files.forEach((f) => formData.append('files', f));
    try {
      setProgress(50);
      const res = await api.post('/api/import', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      setProgress(100);
      setResult(res.data);
    } catch (err) {
      setResult({ success: false, error: err.response?.data?.error ?? err.message, log: [], errors: [] });
    } finally { setLoading(false); }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Import des données</h1>

      <Card>
        <CardTitle className="mb-1 flex items-center gap-2">
          <Upload size={16} className="text-indigo-500" /> Sélection des fichiers
        </CardTitle>
        <p className="text-xs text-slate-400 mb-4">
          Fichiers attendus : <code className="bg-slate-100 px-1 rounded">fichier1.csv</code>, <code className="bg-slate-100 px-1 rounded">fichier2.csv</code>, <code className="bg-slate-100 px-1 rounded">fichier3.csv</code>, <code className="bg-slate-100 px-1 rounded">images.zip</code>
        </p>

        <div
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
            dragOver ? 'border-indigo-400 bg-indigo-50' : 'border-slate-200 bg-slate-50 hover:border-indigo-300'
          }`}
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
        >
          <Upload size={32} className="mx-auto mb-2 text-slate-300" />
          {files.length === 0 ? (
            <p className="text-sm text-slate-400">Cliquer ou glisser-déposer les fichiers ici</p>
          ) : (
            <div className="flex flex-wrap gap-2 justify-center">
              {files.map((f, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 bg-white border border-slate-200 rounded-full px-3 py-1 text-xs font-medium">
                  <FileText size={12} className="text-indigo-400" /> {f.name}
                </span>
              ))}
            </div>
          )}
        </div>
        <input ref={inputRef} type="file" multiple accept=".csv,.zip" className="hidden" onChange={(e) => handleFiles(e.target.files)} />

        {preview.length > 0 && (
          <div className="mt-5 space-y-3">
            {preview.map((p, i) => {
              const hasErr = p.errors.length > 0;
              return (
                <div key={i} className={`rounded-xl border overflow-hidden ${hasErr ? 'border-red-200' : 'border-emerald-200'}`}>
                  <div className={`flex items-center justify-between px-4 py-2.5 ${hasErr ? 'bg-red-50' : 'bg-emerald-50'}`}>
                    <span className="text-sm font-semibold flex items-center gap-2">
                      <FileText size={14} className={hasErr ? 'text-red-400' : 'text-emerald-500'} />
                      {p.file}
                    </span>
                    <div className="flex items-center gap-2">
                      <Badge variant={hasErr ? 'danger' : 'success'}>{TYPE_LABELS[p.type] ?? p.type}</Badge>
                      {p.total > 0 && <span className="text-xs text-slate-400">{p.total} ligne(s)</span>}
                    </div>
                  </div>

                  {p.errors.length > 0 && (
                    <div className="px-4 py-3 bg-red-50 border-t border-red-100">
                      <p className="text-xs font-semibold text-red-600 mb-1 flex items-center gap-1">
                        <AlertCircle size={12} /> Erreurs de validation
                      </p>
                      <ul className="space-y-0.5">
                        {p.errors.map((e, j) => (
                          <li key={j} className="text-xs text-red-500">
                            <em>{e.column}</em>{e.row > 0 && ` (ligne ${e.row})`} — {e.message}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {p.rows.length > 0 && (
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs border-collapse">
                        <thead className="bg-slate-50">
                          <tr>
                            {p.columns.map((col, j) => (
                              <th key={j} className="px-3 py-2 text-left text-slate-500 font-semibold border-b border-slate-100 whitespace-nowrap">{col}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {p.rows.map((row, j) => (
                            <tr key={j} className={j % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                              {p.columns.map((col, k) => (
                                <td key={k} className="px-3 py-1.5 border-b border-slate-50 max-w-[160px] truncate text-slate-600">{row[col] ?? ''}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {p.total > 5 && <p className="text-xs text-slate-400 px-3 py-1.5">… {p.total - 5} ligne(s) supplémentaire(s)</p>}
                    </div>
                  )}
                </div>
              );
            })}

            {hasErrors && (
              <div className="flex items-center gap-2 text-red-600 text-sm font-semibold">
                <X size={16} /> Import bloqué — corriger les erreurs ci-dessus.
              </div>
            )}
          </div>
        )}

        <div className="mt-5 flex items-center gap-4">
          <Button onClick={handleImport} disabled={loading || files.length === 0 || hasErrors}>
            <Upload size={15} /> {loading ? 'Import en cours…' : 'Importer'}
          </Button>
          {files.length > 0 && (
            <button onClick={() => { setFiles([]); setPreview([]); setResult(null); }} className="text-sm text-slate-400 hover:text-slate-600">
              Effacer
            </button>
          )}
        </div>

        {loading && (
          <div className="mt-4 h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-2 bg-indigo-500 rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
        )}
      </Card>

      {result && (
        <Card>
          {result.success ? (
            <div className="flex items-center gap-2 text-emerald-600 font-semibold mb-3">
              <CheckCircle size={18} /> Import terminé ({result.log?.length ?? 0} opérations)
            </div>
          ) : (
            <div className="flex items-center gap-2 text-red-600 font-semibold mb-3">
              <AlertCircle size={18} /> Erreur : {result.error}
            </div>
          )}
          {result.log?.length > 0 && (
            <pre className="bg-slate-900 text-green-400 text-xs font-mono p-4 rounded-lg max-h-72 overflow-y-auto whitespace-pre-wrap">
              {result.log.join('\n')}
            </pre>
          )}
          {result.errors?.length > 0 && (
            <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-xs font-semibold text-red-600 mb-1">Erreurs d'import :</p>
              <ul className="space-y-0.5">
                {result.errors.map((e, i) => <li key={i} className="text-xs text-red-500">{e}</li>)}
              </ul>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
