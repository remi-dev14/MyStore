import { useState, useEffect } from 'react';
import { prestaGet, api } from '../../../config/api.js';
import { parsePrestaXml, extractList, getLangValue } from '../../../utils/xmlParser.js';
import { Card, CardTitle } from '../../../shared/ui/Card.jsx';
import { Button } from '../../../shared/ui/Button.jsx';
import { Table, Thead, Th, Tbody, Tr, Td } from '../../../shared/ui/Table.jsx';
import { Spinner } from '../../../shared/ui/Spinner.jsx';
import { ChevronDown, ChevronUp, Plus, Box } from 'lucide-react';

export default function StockAddPage() {
  const [products, setProducts] = useState([]);
  const [selected, setSelected] = useState('');
  const [delta, setDelta] = useState(1);
  const [combinations, setCombinations] = useState([]);
  const [selectedCombination, setSelectedCombination] = useState('0');
  const [stockTotals, setStockTotals] = useState({});
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [expandedRows, setExpandedRows] = useState([]);
  const [expandLoading, setExpandLoading] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const [prodXml, stockXml] = await Promise.all([
          prestaGet('products', { display: 'full', output_format: 'XML' }),
          prestaGet('stock_availables', { display: 'full', output_format: 'XML' }),
        ]);
        const list = extractList(parsePrestaXml(prodXml), 'products');
        setProducts(list);
        if (list.length) setSelected(list[0].id);

        const saList = extractList(parsePrestaXml(stockXml), 'stock_availables');
        const totals = {};
        saList.forEach((sa) => {
          const pid = String(sa.id_product);
          totals[pid] = (totals[pid] ?? 0) + (parseInt(sa.quantity, 10) || 0);
        });
        setStockTotals(totals);
      } catch (e) { setError(e.message); }
    }
    load();
  }, []);

  useEffect(() => {
    async function loadCombinations() {
      if (!selected) return;
      try {
        const xml = await prestaGet('combinations', { 'filter[id_product]': selected, display: 'full', output_format: 'XML' });
        setCombinations(extractList(parsePrestaXml(xml), 'combinations') || []);
        setSelectedCombination('0');
      } catch { setCombinations([]); }
    }
    loadCombinations();
  }, [selected]);

  async function toggleExpand(productId) {
    if (expandedId === productId) { setExpandedId(null); setExpandedRows([]); return; }
    setExpandedId(productId);
    setExpandedRows([]);
    setExpandLoading(true);
    try {
      const [combXml, stockXml] = await Promise.all([
        prestaGet('combinations', { 'filter[id_product]': productId, display: 'full', output_format: 'XML' }),
        prestaGet('stock_availables', { 'filter[id_product]': productId, display: 'full', output_format: 'XML' }),
      ]);
      const combList = extractList(parsePrestaXml(combXml), 'combinations') || [];
      const stockList = extractList(parsePrestaXml(stockXml), 'stock_availables') || [];
      const stockMap = {};
      stockList.forEach((s) => { stockMap[String(s.id_product_attribute ?? '0')] = parseInt(s.quantity ?? 0, 10); });

      const rows = combList.length === 0
        ? [{ label: 'Produit simple', quantity: stockMap['0'] ?? 0 }]
        : combList.map((c) => ({
            label: c.reference ? `${c.reference} (id=${c.id})` : `Déclinaison #${c.id}`,
            quantity: stockMap[String(c.id)] ?? 0,
          }));
      setExpandedRows(rows);
    } catch { setExpandedRows([]); }
    finally { setExpandLoading(false); }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    try {
      const body = { productId: selected, delta: parseInt(delta, 10) };
      if (selectedCombination === 'all') body.applyToAll = true;
      else if (selectedCombination !== '0') body.productAttributeId = selectedCombination;
      const res = await api.post('/api/stock/add', body);
      setResult(res.data);
      if (expandedId === selected) { setExpandedId(null); setTimeout(() => toggleExpand(selected), 300); }
    } catch (e) { setError(e.response?.data?.error ?? e.message); }
    finally { setLoading(false); }
  }

  const filteredProducts = products.filter((p) =>
    getLangValue(p.name, 1).toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Stock</h1>
      {error && <p className="text-red-500 text-sm">{error}</p>}

      {/* Add stock form */}
      <Card>
        <CardTitle className="mb-4 flex items-center gap-2">
          <Plus size={16} className="text-indigo-500" /> Ajouter du stock
        </CardTitle>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Produit</label>
            <select
              value={selected}
              onChange={(e) => setSelected(e.target.value)}
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-300"
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>{getLangValue(p.name, 1)} (id={p.id})</option>
              ))}
            </select>
          </div>

          {combinations.length > 0 && (
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Déclinaison</label>
              <select
                value={selectedCombination}
                onChange={(e) => setSelectedCombination(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-300"
              >
                <option value="all">Toutes</option>
                <option value="0">Produit principal</option>
                {combinations.map((c) => (
                  <option key={c.id} value={c.id}>{c.reference || `Déclinaison id=${c.id}`}</option>
                ))}
              </select>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Quantité</label>
            <input
              type="number" min="1" value={delta}
              onChange={(e) => setDelta(e.target.value)}
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300"
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            <Plus size={15} /> {loading ? 'En cours...' : 'Ajouter'}
          </Button>
        </form>

        {result && (
          <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-sm text-emerald-700">
            <strong>Stock mis à jour</strong>
            {result.oldQty !== undefined && <span className="ml-2">Avant : {result.oldQty}</span>}
            {result.newQty !== undefined && <span className="ml-2">→ Après : {result.newQty}</span>}
          </div>
        )}
      </Card>

      {/* Stock list */}
      <Card>
        <div className="flex items-center gap-4 mb-5">
          <CardTitle className="flex items-center gap-2"><Box size={16} className="text-indigo-500" /> Liste du stock</CardTitle>
          <div className="flex-1" />
          <input
            placeholder="Rechercher..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="text-sm border border-slate-200 rounded-lg px-3 py-1.5 w-52 focus:outline-none focus:ring-2 focus:ring-indigo-300"
          />
        </div>

        <Table>
          <Thead>
            <tr>
              <Th>Produit</Th>
              <Th right>Stock total</Th>
              <Th className="w-10"></Th>
            </tr>
          </Thead>
          <Tbody>
            {filteredProducts.map((p) => {
              const isExpanded = expandedId === p.id;
              const total = stockTotals[String(p.id)] ?? 0;
              return [
                <Tr key={`r-${p.id}`} onClick={() => toggleExpand(p.id)} className={isExpanded ? 'bg-indigo-50' : ''}>
                  <Td className={isExpanded ? 'font-semibold text-indigo-700' : 'font-medium'}>
                    {getLangValue(p.name, 1)}
                    <span className="text-slate-400 text-xs ml-2">id={p.id}</span>
                  </Td>
                  <Td right>
                    <span className={`font-bold ${total === 0 ? 'text-red-400' : 'text-emerald-600'}`}>{total}</span>
                  </Td>
                  <Td className="w-10 text-center">
                    {isExpanded
                      ? <ChevronUp size={15} className="text-indigo-400" />
                      : <ChevronDown size={15} className="text-slate-300" />}
                  </Td>
                </Tr>,

                isExpanded && (
                  <tr key={`x-${p.id}`} className="bg-indigo-50/60">
                    <td colSpan={3} className="px-0 py-0">
                      {expandLoading ? (
                        <p className="text-xs text-slate-400 italic px-8 py-3">Chargement...</p>
                      ) : (
                        <table className="w-full text-xs border-collapse">
                          <thead>
                            <tr className="bg-indigo-100/60">
                              <th className="text-left px-8 py-2 text-indigo-600 font-semibold">Déclinaison</th>
                              <th className="text-right px-6 py-2 text-indigo-600 font-semibold w-28">Stock</th>
                            </tr>
                          </thead>
                          <tbody>
                            {expandedRows.map((row, i) => (
                              <tr key={i} className="border-t border-indigo-100">
                                <td className="px-8 py-2 font-medium text-slate-600">{row.label}</td>
                                <td className={`px-6 py-2 text-right font-bold ${row.quantity === 0 ? 'text-red-400' : 'text-emerald-600'}`}>
                                  {row.quantity}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      )}
                    </td>
                  </tr>
                ),
              ];
            })}
          </Tbody>
        </Table>

        {filteredProducts.length === 0 && <p className="text-sm text-slate-400 mt-4">Aucun produit.</p>}
      </Card>
    </div>
  );
}
