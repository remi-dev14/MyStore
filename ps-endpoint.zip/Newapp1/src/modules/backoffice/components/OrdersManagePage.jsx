import { useState, useEffect, useCallback } from 'react';
import { prestaGet, api } from '../../../config/api.js';
import { parsePrestaXml, extractList, getLangValue } from '../../../utils/xmlParser.js';
import { isoToFr } from '../../../utils/dateUtils.js';
import { Card } from '../../../shared/ui/Card.jsx';
import { Badge } from '../../../shared/ui/Badge.jsx';
import { Table, Thead, Th, Tbody, Tr, Td } from '../../../shared/ui/Table.jsx';
import { Spinner } from '../../../shared/ui/Spinner.jsx';

const EDITABLE_STATES = [
  { id: '2', label: 'Paiement accepté' },
  { id: '6', label: 'Annulé' },
];

function stateLabel(id) {
  const s = String(id);
  if (s === '2' || s === '11') return 'Paiement accepté';
  if (s === '6') return 'Annulé';
  return `État ${s}`;
}

function stateVariant(id) {
  const s = String(id);
  if (s === '2' || s === '11') return 'success';
  if (s === '6') return 'danger';
  return 'default';
}

function customerName(c) {
  const first = typeof c.firstname === 'string' ? c.firstname : (getLangValue(c.firstname) || '');
  const last  = typeof c.lastname  === 'string' ? c.lastname  : (getLangValue(c.lastname)  || '');
  return `${first} ${last}`.trim();
}

export default function OrdersManagePage() {
  const [orders, setOrders] = useState([]);
  const [customerMap, setCustomerMap] = useState({});
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(null);
  const [error, setError] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [ordersXml, custXml] = await Promise.all([
        prestaGet('orders', { display: 'full', output_format: 'XML' }),
        prestaGet('customers', { display: 'full', output_format: 'XML' }),
      ]);
      setOrders(extractList(parsePrestaXml(ordersXml), 'orders'));
      const map = {};
      extractList(parsePrestaXml(custXml), 'customers').forEach((c) => { map[c.id] = customerName(c); });
      setCustomerMap(map);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  async function handleStateChange(orderId, newState) {
    setUpdating(orderId);
    try {
      await api.put(`/api/orders/${orderId}/state`, { current_state: newState });
      setOrders((prev) => prev.map((o) => o.id === orderId ? { ...o, current_state: newState } : o));
    } catch (e) { alert('Erreur : ' + e.message); }
    finally { setUpdating(null); }
  }

  if (loading) return <Spinner />;

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Commandes</h1>
      {error && <p className="text-red-500 text-sm">{error}</p>}

      <Card>
        {orders.length === 0 ? (
          <p className="text-sm text-slate-400">Aucune commande trouvée.</p>
        ) : (
          <Table>
            <Thead>
              <tr>
                <Th>Référence</Th>
                <Th>Client</Th>
                <Th>Date</Th>
                <Th right>Total TTC</Th>
                <Th>État</Th>
                <Th>Modifier</Th>
              </tr>
            </Thead>
            <Tbody>
              {orders.map((o) => (
                <Tr key={o.id}>
                  <Td className="font-medium text-slate-500">{o.reference ?? `#${o.id}`}</Td>
                  <Td className="font-medium">{customerMap[o.id_customer] || `Client #${o.id_customer}`}</Td>
                  <Td className="text-slate-500">{isoToFr(o.date_add)}</Td>
                  <Td right className="font-semibold">{parseFloat(o.total_paid ?? 0).toFixed(2)} €</Td>
                  <Td><Badge variant={stateVariant(o.current_state)}>{stateLabel(o.current_state)}</Badge></Td>
                  <Td>
                    <select
                      className="text-xs border border-slate-200 rounded-md px-2 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-300"
                      value={String(o.current_state) === '11' ? '2' : o.current_state}
                      onChange={(e) => handleStateChange(o.id, e.target.value)}
                      disabled={updating === o.id}
                    >
                      {EDITABLE_STATES.map((s) => (
                        <option key={s.id} value={s.id}>{s.label}</option>
                      ))}
                    </select>
                    {updating === o.id && <span className="ml-2 text-xs text-slate-400">...</span>}
                  </Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
