import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, User, Truck, CreditCard, Check, ArrowLeft, AlertCircle } from 'lucide-react';
import { useCart } from '../../../context/CartContext.jsx';
import { useUser } from '../../../context/UserContext.jsx';
import { api, prestaGet } from '../../../config/api.js';
import { parsePrestaXml, extractList, extractId } from '../../../utils/xmlParser.js';
import { buildCartXml, buildOrderXml, buildAddressXml } from '../../../utils/xmlBuilder.js';

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const { user } = useUser();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleConfirm() {
    if (!user || user.isAnonymous) {
      setError('Veuillez sélectionner un compte utilisateur pour commander.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const addrXml = await prestaGet('addresses', {
        display: 'full',
        [`filter[id_customer]`]: user.id,
        output_format: 'XML',
      });
      const addrList = extractList(parsePrestaXml(addrXml), 'addresses');
      let addr = addrList[0];

      // Auto-create a default address if none exists
      if (!addr) {
        const nameParts = user.name.trim().split(' ');
        const firstname = nameParts[0] || 'Client';
        const lastname = nameParts.slice(1).join(' ') || firstname;
        const newAddrXml = buildAddressXml({
          id_customer: user.id,
          alias: 'Principale',
          address1: 'Adresse par défaut',
          city: 'Antananarivo',
          postcode: '101',
          id_country: 8,
          firstname,
          lastname,
        });
        const addrRes = await api.post('/api/presta/addresses', newAddrXml, {
          headers: { 'Content-Type': 'application/xml' },
        });
        const newAddrId = extractId(parsePrestaXml(addrRes.data), 'address');
        if (!newAddrId) throw new Error('Impossible de créer une adresse pour ce client.');
        addr = { id: newAddrId };
      }

      const cartRows = items.map((item) => ({
        product_id: item.product.id,
        product_attribute_id: item.product.id_product_attribute ?? 0,
        quantity: item.quantity,
        id_shop: 1,
      }));

      const cartXml = buildCartXml({
        id_customer: user.id,
        id_address_delivery: addr.id,
        id_address_invoice: addr.id,
        cartRows,
      });
      const cartRes = await api.post('/api/presta/carts', cartXml, {
        headers: { 'Content-Type': 'application/xml' },
      });
      const cartId = extractId(parsePrestaXml(cartRes.data), 'cart');
      if (!cartId) throw new Error('Impossible de créer le panier.');

      const orderRows = items.map((item) => {
        const price = parseFloat(item.product.price_ttc ?? item.product.price ?? 0);
        return {
          product_id: item.product.id,
          product_attribute_id: item.product.id_product_attribute ?? 0,
          product_name: item.product.name,
          product_reference: item.product.id,
          quantity: item.quantity,
          product_price: price,
          unit_price_tax_incl: price,
          unit_price_tax_excl: price,
        };
      });

      const orderXml = buildOrderXml({
        id_customer: user.id,
        id_cart: cartId,
        id_address_delivery: addr.id,
        id_address_invoice: addr.id,
        current_state: 2,
        payment: 'Cash on delivery',
        module: 'ps_cashondelivery',
        total_paid: total.toFixed(2),
        total_paid_real: total.toFixed(2),
        total_products: total.toFixed(2),
        total_products_wt: total.toFixed(2),
        orderRows,
      });
      await api.post('/api/presta/orders', orderXml, {
        headers: { 'Content-Type': 'application/xml' },
      });

      // Decrement stock for each ordered item
      await Promise.allSettled(items.map((item) => {
        const body = {
          productId: item.product.id,
          delta: -item.quantity,
        };
        const attrId = item.product.id_product_attribute;
        if (attrId && String(attrId) !== '0') body.productAttributeId = attrId;
        return api.post('/api/stock/add', body);
      }));

      clearCart();
      navigate('/my-orders');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <ShoppingBag className="w-16 h-16 text-gray-200 mb-4" />
        <p className="text-gray-500 mb-4">Votre panier est vide.</p>
        <Link to="/products" className="text-indigo-600 font-medium hover:underline text-sm">
          Retour aux produits
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Link to="/cart" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-500" />
        </Link>
        <h1 className="text-2xl font-black text-gray-900">Confirmation de commande</h1>
      </div>

      <div className="flex items-center gap-2 mb-8 text-xs font-medium">
        <div className="flex items-center gap-1.5 text-emerald-600">
          <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
            <Check className="w-3 h-3" />
          </div>
          Panier
        </div>
        <div className="flex-1 h-px bg-indigo-200" />
        <div className="flex items-center gap-1.5 text-indigo-600 font-semibold">
          <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px] font-bold">2</div>
          Confirmation
        </div>
        <div className="flex-1 h-px bg-gray-200" />
        <div className="flex items-center gap-1.5 text-gray-400">
          <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-[10px] font-bold">3</div>
          Terminé
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <ShoppingBag className="w-4 h-4 text-indigo-500" />
            <h2 className="font-semibold text-gray-900 text-sm">Récapitulatif</h2>
          </div>
          <div className="space-y-3">
            {items.map((item) => {
              const price = parseFloat(item.product.price_ttc ?? item.product.price ?? 0);
              return (
                <div key={item.key} className="flex justify-between items-center text-sm">
                  <span className="text-gray-700">
                    {item.product.name}
                    {item.variant && <span className="text-gray-400"> ({item.variant})</span>}
                    <span className="text-gray-400 ml-1">× {item.quantity}</span>
                  </span>
                  <span className="font-semibold text-gray-900">{(price * item.quantity).toFixed(2)} €</span>
                </div>
              );
            })}
          </div>
          <div className="border-t border-gray-100 mt-4 pt-4 flex justify-between items-center">
            <span className="font-bold text-gray-900">Total TTC</span>
            <span className="text-xl font-black text-indigo-600">{total.toFixed(2)} €</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-3">
            <Truck className="w-4 h-4 text-indigo-500" />
            <h2 className="font-semibold text-gray-900 text-sm">Livraison</h2>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Livraison standard</span>
            <span className="text-emerald-600 font-semibold">Gratuite</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard className="w-4 h-4 text-indigo-500" />
            <h2 className="font-semibold text-gray-900 text-sm">Paiement</h2>
          </div>
          <div className="flex items-center gap-3 p-3 bg-indigo-50 rounded-xl border-2 border-indigo-200">
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
              <Check className="w-4 h-4 text-indigo-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-indigo-900">Paiement à la livraison</p>
              <p className="text-xs text-indigo-500">Vous payez à réception de votre colis</p>
            </div>
          </div>
        </div>

        {user && !user.isAnonymous && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <User className="w-4 h-4 text-indigo-500" />
              <h2 className="font-semibold text-gray-900 text-sm">Client</h2>
            </div>
            <p className="text-sm text-gray-700">
              Commande au nom de <strong>{user.name}</strong>
            </p>
          </div>
        )}
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 flex items-start gap-2.5 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm"
        >
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          {error}
        </motion.div>
      )}

      <div className="mt-6 space-y-3">
        <button
          onClick={handleConfirm}
          disabled={loading || !user || user.isAnonymous}
          className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-colors shadow-sm disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Traitement en cours...
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              Confirmer la commande
            </>
          )}
        </button>

        {user?.isAnonymous && (
          <p className="text-center text-sm text-red-500">
            Un compte est requis pour commander.{' '}
            <Link to="/" className="font-semibold underline">Choisir un utilisateur</Link>
          </p>
        )}
      </div>
    </div>
  );
}
